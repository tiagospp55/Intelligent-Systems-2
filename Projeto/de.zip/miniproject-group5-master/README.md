# Morty Chat bot

A react based interface for chatting with our own chatbot called Morty

The goal is to create a chat bot that is able to ask questions about what the user likes and try to determine an ideal travel destination!


## Starting the Application Locally

### SWI-Prolog/Dataset  

The data for this project along with some key functions are inside the file database/database.pl  
Pengines installation is required: https://pengines.swi-prolog.org/docs/getting_started.html  
* swipl database/database.pl

### Flask Rest API  
We developed a simple rest api with flask to communicate with the Pengine Server  
Install rest-api/requirements.txt and then run  
* python rest-api/app.py  

### ChatBot ReactJs  
The web platform is developed in react_website  
* sudo apt install npm  
* npm i compromise  
* npm i lodash.debounce  
* npm i damerau-levenshtein-js


*NOTE: Our Application Requires An Up to date Version of Npm*
- Upgrade: npm install -g npm@latest


## Deployed Application

The application has been deployed and is accessbile here:
* LINK: https://si.bearkillerpt.xyz/
